# x16-xmas
Christmas 2019 Demo for Commander X16

run **build.sh** from bash, then load and run **XMAS2019.PRG**. Make sure you also have all the **.BIN** files!

As seen on YouTube: https://youtu.be/OQl3hvR8Odg
